<?php if(count($projects)): ?>
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-lg-4 col-md-6">
            <div class="card">
                <div class="card-image">
                    <a href="<?php echo e($project->link()); ?>">
                        <img src="<?php echo e($project->img); ?>"
                             alt="<?php echo e($project->name); ?>">
                    </a>
                </div>
                <div class="card-body">
                    <?php if($project->banned): ?>
                        <a href="<?php echo e($project->link()); ?>" class="text-danger">
                            <h4 class="card-title"><?php echo e($project->banned); ?></h4>
                        </a>
                        <p class="card-description">
                            作品审查中
                        </p>
                    <?php else: ?>
                        <a href="<?php echo e($project->link()); ?>">
                            <h4 class="card-title"><?php echo e($project->name); ?></h4>
                        </a>
                        <p class="card-description">
                            <?php echo e($project->summary); ?>

                        </p>
                    <?php endif; ?>
                    <div class="card-footer">
                        <span><?php echo e($project->user->name); ?></span>
                    </div>
                </div>
            </div> <!-- end card -->
        </div>

        <?php if($loop->iteration == 12) break; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    暂无数据
<?php endif; ?>