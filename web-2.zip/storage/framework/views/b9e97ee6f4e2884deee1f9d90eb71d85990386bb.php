<?php $__env->startSection('title', '作品列表'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <div class="page-header page-header-small">
            <div class="page-header-image" data-parallax="true"
                 style="background-image: url('http://web-cdn-1252712503.file.myqcloud.com/img/projects/1.png?name=玄霄阁');">
            </div>
        </div>
        <div class="main">
            <div class="section">
                <div class="container">
                    <h2 class="section-title">作品列表</h2>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="collapse-panel">
                                <div class="card-body">
                                    <form method="GET" action="<?php echo e(route('projects.index')); ?>" onreset="this.submit()">
                                        <div class="card card-refine card-plain">
                                            <h4 class="card-title">
                                                条件筛选
                                                <button type="reset" class="btn btn-default btn-icon btn-neutral pull-right"
                                                        rel="tooltip" data-original-title="重置">
                                                    <i class="arrows-1_refresh-69 now-ui-icons"></i>
                                                </button>
                                            </h4>

                                            <div class="card card-refine card-plain">
                                                <div class="input-group">
                                                    <div class="input-group-addon">
                                                        <span class="input-group-text small text-muted">作者</span>
                                                    </div>
                                                    <select name="author" id="author-choose" class="form-control">
                                                        <option value selected>--- 请选择 ---</option>
                                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(!empty($_GET['author']) && $_GET['author'] == $user->id): ?>
                                                                <option value="<?php echo e($user->id); ?>" selected><?php echo e($user->name); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <button class="btn btn-primary btn-block">确认</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-9">
                            <div class="row">

                                <?php echo $__env->make('projects._list', ['projects' => $projects], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- section -->

        </div> <!-- end-main-raised -->

        <?php echo $__env->make('layouts._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>