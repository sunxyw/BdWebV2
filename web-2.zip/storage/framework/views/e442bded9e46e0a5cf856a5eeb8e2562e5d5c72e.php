<?php $__env->startSection('title', $project->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header page-header-small">
        <div class="page-header-image" data-parallax="true"
             style="background-image: url('<?php echo e($project->img); ?>');"
             id="banner">
        </div>
    </div>

    <div class="section">
        <div class="container">
            <div class="row">
                <?php if($project->banned): ?>
                    <div class="mr-auto ml-auto text-danger text-center">
                        <h1 class="title">十分抱歉</h1>
                        <h1>该作品已<?php echo e($project->banned); ?></h1>
                        <hr>
                        <div class="social-line text-white">
                            <a class="btn btn-warning mr-3">申诉</a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ban', $project)): ?>
                                <button class="btn btn-warning mr-3" type="button" onclick="document.getElementById('unban-form').submit();">
                                    解除封禁
                                </button>
                                <form action="<?php echo e(route('projects.destroy', $project->id)); ?>" method="POST" id="unban-form">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <input type="hidden" name="action" value="ban">
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php else: ?>
                <div class="col-md-6">

                    <div id="productCarousel" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active">
                                <img class="d-block img-raised" src="<?php echo e($project->img); ?>" id="img"
                                     style="max-height: 450px">
                            </div>
                        </div>
                    </div>

                    <br>

                </div>
                <div class="col-md-6 ml-auto mr-auto">
                    <h2 class="title"><?php echo e($project->name); ?></h2>
                    <h5 class="category"><?php echo e($project->user->name); ?> 
                        <small class="pull-right">点击量: <?php echo e($project->view_count); ?></small>
                    </h5>

                    <div id="accordion" role="tablist" aria-multiselectable="true" class="card-collapse">
                        <div class="card">
                            <div class="card-header text-primary" role="tab" id="headingOne">
                                详细资料
                            </div>
                            <div class="card-body">
                                <p><?php echo e($project->summary); ?></p>
                                <p class="text-muted pull-right">
                                    发布于: <?php echo e($project->created_at->diffForHumans()); ?>

                                </p>
                            </div>
                        </div>
                        <div class="row justify-content-end">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $project)): ?>
                                <a class="btn btn-warning mr-3" href="<?php echo e(route('projects.edit', $project->id)); ?>">
                                    编辑 <i class="fa fa-edit"></i>
                                </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ban', $project)): ?>
                                <form action="<?php echo e(route('projects.destroy', $project->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button class="btn btn-danger mr-3" type="submit" name="action" value="ban">
                                        封禁 <i class="fa fa-ban"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy', $project)): ?>
                                <form action="<?php echo e(route('projects.destroy', $project->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button class="btn btn-danger mr-3" type="submit">
                                        删除 <i class="fa fa-remove"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                            <button class="btn btn-primary mr-3">下载 <i class="fa fa-download"></i></button>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
    <?php echo $__env->make('layouts._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>