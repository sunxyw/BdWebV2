<footer class="footer footer-{{ $type or 'default' }}">
    <div class="container">
        <div class="copyright">
            Copyright &copy; <a href="#">Build-Dragon</a>. All Right Reserved.
        </div>
    </div>
</footer>